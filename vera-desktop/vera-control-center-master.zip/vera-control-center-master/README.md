Vera Control Center
===================

Vera Control Center is a simple, fast, modular control center written in Python.  
It's written mainly for the Vera desktop environment and the Semplice Linux distribution.
