vera-plugin-alan-watcher
========================

This is the alan2 watcher plugin for vera.
It's basically the very same shitty code of the 'normal' alan-watcher, repackaged
for vera.
